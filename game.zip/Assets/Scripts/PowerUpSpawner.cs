﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpSpawner : MonoBehaviour
{
    private Player player;
    public GameObject damage;
    int d = 1;
    public GameObject fast;
    int f = 2;
    public GameObject heal;
    int h = 3;
    public GameObject armor;
    int a = 4;
    public Transform[] spawnSpots;
    int randUnit1;
    float timeBtwSpawns;
    float startTimeBtwSpawns = 1.0f;

    void Start(){
      player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
    }

    void Update()
    { if( timeBtwSpawns <= 0 ){
        if(player.timer % 20 == 0 && player.timer != 0){
          int randPos1 = Random.Range(0, spawnSpots.Length);
          int randUp = Random.Range(1,5);
          if(randUp == d){
            Debug.Log("DAMAGE");
            Instantiate(damage, spawnSpots[randPos1].position, Quaternion.identity);
          }
          if(randUp == f){
            Debug.Log("FAST");
            Instantiate(fast, spawnSpots[randPos1].position, Quaternion.identity);
          }
          if(randUp == h){
            Debug.Log("HEAL");
            Instantiate(heal, spawnSpots[randPos1].position, Quaternion.identity);
          }
          if(randUp == a){
            Debug.Log("ARMOR");
            Instantiate(armor, spawnSpots[randPos1].position, Quaternion.identity);
          }
        }
        timeBtwSpawns = startTimeBtwSpawns;
      }
      else{
        timeBtwSpawns -= Time.deltaTime;
      }
    }
}
