﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pUptime1 : MonoBehaviour
{
    public GameObject dmg_bar;
	float i = 400;
	float scale = 1;
    void FixedUpdate()
    {
        transform.localScale = new Vector3(scale, 1f);
	    i--;
	    scale = i/400;
	    if(i == 0){
	    	Destroy(dmg_bar);
	    }    
    }
}
