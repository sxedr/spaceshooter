﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class smallEnemy : MonoBehaviour
{
    public float speed = 6.0f;
    private Transform playerPos;
    private Player player;
    public GameObject effect;
    public Projectile projectile;
    public int shealth = 1;

    public float vspeed = 10.0f;
    private Vector2 currentDirection = new Vector3(0.0f, 1.0f, 0.0f);


    void Start(){
    	player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
    	playerPos = GameObject.FindGameObjectWithTag("Player").transform;

    }

    void Update(){
    	transform.position = Vector2.MoveTowards(transform.position, playerPos.position, speed * Time.deltaTime);

    	Vector2 playerPosition = player.transform.position;
    	Vector2 objectPos = gameObject.transform.position;
    	Vector2 direction = playerPosition - objectPos;
    	direction.Normalize();
    	currentDirection = Vector2.Lerp( currentDirection, direction, Time.deltaTime * vspeed );
    	gameObject.transform.up = currentDirection;
    } 

    void OnTriggerEnter2D(Collider2D other){
    	if(other.CompareTag("Player")){
    		Instantiate(effect, transform.position, Quaternion.identity);
    		player.health -=1;
    		Destroy(gameObject);
    	}

    	if(other.CompareTag("Projectile") || other.CompareTag("Winchester")){
    		shealth -=player.attack;
    		if( shealth <= 0 ){
    			Instantiate(effect, transform.position, Quaternion.identity);
    			Destroy(gameObject);
    			player.points +=1;
                GetComponent <AudioSource>().Play();
    		}
    	}
        if(other.CompareTag("shieldRight") || other.CompareTag("shieldLeft")){
            Destroy(gameObject);
            Instantiate(effect, transform.position, Quaternion.identity);
            GetComponent <AudioSource>().Play();
        }
    }
}
