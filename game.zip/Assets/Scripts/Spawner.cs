﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject enemy;
    public GameObject fastEnemy;
    public GameObject bigEnemy;
    public Transform[] spawnSpots;
    private float timeBtwSpawns;
    private Player player;
    public float startTimeBtwSpawns;
    public int i = 0;
    int randUnit1;

    void Start(){
  		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
      timeBtwSpawns = startTimeBtwSpawns;
    }
    void Update(){
   		if( timeBtwSpawns <= 0 ){
   			if( player.timer < 20 ){
   				int randPos1 = Random.Range(0, spawnSpots.Length - 1);
   				Instantiate(enemy, spawnSpots[randPos1].position, Quaternion.identity);
   				startTimeBtwSpawns = 1.0f;
   			}
   			if( player.timer >= 25 && player.timer < 45 ){
   				startTimeBtwSpawns = 0.9f;
   				int randPos1 = Random.Range(0,spawnSpots.Length - 1);
   				randUnit1 = Random.Range(1,4);
   				if(randUnit1 == 1 || randUnit1 == 3){
   					Instantiate(enemy, spawnSpots[randPos1].position, Quaternion.identity);
   				}
   				if(randUnit1 == 2){
   					Instantiate(fastEnemy, spawnSpots[randPos1].position, Quaternion.identity);
   				}
   			}
   			if( player.timer>= 50 && player.timer < 80){
   				startTimeBtwSpawns = 0.85f;
   				int randPos1 = Random.Range(0,spawnSpots.Length - 1);
   				randUnit1 = Random.Range(1,9);
   				if(randUnit1 == 1 || randUnit1 == 3 || randUnit1 == 4 || randUnit1 == 8){
   					Instantiate(enemy, spawnSpots[randPos1].position, Quaternion.identity);
   				}
   				if(randUnit1 == 2 || randUnit1 == 5 || randUnit1 == 7){
   					Instantiate(fastEnemy, spawnSpots[randPos1].position, Quaternion.identity);
   				}
   				if(randUnit1 == 6){
   					Instantiate(bigEnemy, spawnSpots[randPos1].position, Quaternion.identity);
   				}
   			}
        if( player.timer>= 90 ){
          startTimeBtwSpawns = 0.8f;
          int randPos1 = Random.Range(0,spawnSpots.Length - 1);
          randUnit1 = Random.Range(1,9);
          if(randUnit1 == 1 || randUnit1 == 3 || randUnit1 == 4 || randUnit1 == 8){
            Instantiate(enemy, spawnSpots[randPos1].position, Quaternion.identity);
          }
          if(randUnit1 == 2 || randUnit1 == 5 || randUnit1 == 7){
            Instantiate(fastEnemy, spawnSpots[randPos1].position, Quaternion.identity);
          }
          if(randUnit1 == 6){
            Instantiate(bigEnemy, spawnSpots[randPos1].position, Quaternion.identity);
          }
        }
   			timeBtwSpawns = startTimeBtwSpawns;
   		}
   		else{
   			timeBtwSpawns -= Time.deltaTime;
   		}
    }
}
