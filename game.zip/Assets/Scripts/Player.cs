﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
	public GameObject wall;
    public float speed = 7.0f;
    public float vspeed = 5.0f;
    private Vector2 currentDirection = new Vector3(0.0f, 1.0f, 0.0f);
    private Transform transformObject;
    private Rigidbody2D rb;
    private Vector2 moveVelocity;
	public GameObject bullet; 
    public Text healthDisplay;
    public Text pointsDisplay;
    public int health = 10;
    public int lhealth;
    public int points = 0;
    public int attack = 1;
    public float timed = 0;
    public float timef = 0;
    public float timea = 0;
    public int timer = 0;
    float timeBtwSpawns;
    float startTimeBtwSpawns = 1.0f;
    public int k = 1;
    void Start(){
    	rb = GetComponent<Rigidbody2D>();
    	transformObject = this.transform;
    	timeBtwSpawns = startTimeBtwSpawns;
    }
    void Update(){
    	Vector2 mousePos = Camera.main.ScreenToWorldPoint( Input.mousePosition );
    	Vector2 objectPos = transformObject.position;
    	Vector2 direction = mousePos - objectPos;
    	direction.Normalize();
    	currentDirection = Vector2.Lerp( currentDirection, direction, Time.deltaTime * vspeed );
    	transformObject.up = currentDirection;

    	healthDisplay.text = "TIME: " + timer;
    	pointsDisplay.text = "POINTS: " + points;

	    Vector2 moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
	    moveVelocity = moveInput.normalized * speed;	
		
    	/*if(Input.GetKey(KeyCode.W)){
    		transform.Translate(new Vector2(0, speed)* Time.deltaTime);
    	}
    	if(Input.GetKey(KeyCode.S)){
    		transform.Translate(new Vector2(0, -speed)* Time.deltaTime);
    	}
    	if(Input.GetKey(KeyCode.A)){
    		transform.rotation *= Quaternion.Euler(0f, 0f, 300f*Time.deltaTime);
    	}
    	if(Input.GetKey(KeyCode.D)){
    		transform.rotation *= Quaternion.Euler(0f, 0f, -300f*Time.deltaTime);
    	}*/

    	if( timeBtwSpawns <= 0 ){
    		timer++; 
   			timeBtwSpawns = startTimeBtwSpawns;
    	}
    	else{
    		timeBtwSpawns -= Time.deltaTime;
    	}
    	if(health <= 0){
    		Destroy(gameObject);
    	}
    }
    void FixedUpdate(){
    	if(transform.position.y <= 4.5f && transform.position.y >= -4.5f && transform.position.x <= 7.55f && transform.position.x >= -7.55f){
    		rb.MovePosition(rb.position + moveVelocity * Time.fixedDeltaTime);
    	}
    	if(transform.position.y >= 4.5f){
    		transform.position = new Vector3(transform.position.x, transform.position.y - 0.1f, transform.position.z);
    	}
    	if(transform.position.y <= -4.5f){
    		transform.position = new Vector3(transform.position.x, transform.position.y + 0.1f, transform.position.z);
    	}
    	if(transform.position.x >= 7.55f){
    		transform.position = new Vector3(transform.position.x - 0.1f, transform.position.y, transform.position.z);
    	}
    	if(transform.position.x <= -7.55f){
    		transform.position = new Vector3(transform.position.x + 0.1f, transform.position.y, transform.position.z);
    	}
    	if(attack == 2){
    		timed ++;
    		if(timed == 400){
    			Debug.Log("normal attack");
    			timed = 0;
    			attack = 1;
    		}
    	}
    	if(speed == 8.5f){
    		timef ++;
    		if(timef == 400){
    			Debug.Log("normal speed");
    			timef = 0;
    			speed = 7.0f;
    		}
    	}
    	if(health > 10){
    		timea ++;
    		if(timea == 200){
    			Debug.Log("without shield");
    			timea = 0;
    			health = lhealth;
    		}
    	}
    }
    
    
}
