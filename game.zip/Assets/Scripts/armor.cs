﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class armor : MonoBehaviour
{
	public GameObject shield_bar;
    private Player player;
    public GameObject shieldLeft;
    public GameObject shieldRight;
	int timer;
	void Start(){
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
	}
	void Update(){
		timer++;
		if(timer == 1000){
			Destroy(gameObject);
			Debug.Log("DesArm");
		}

	}
	void OnTriggerEnter2D(Collider2D other){
    	if(other.CompareTag("Player")){
   			Instantiate(shieldLeft, new Vector3( player.transform.position.x-0.4f, player.transform.position.y, player.transform.position.z ), Quaternion.identity);
   			Instantiate(shieldRight, new Vector3( player.transform.position.x+0.4f, player.transform.position.y, player.transform.position.z ), Quaternion.identity);
    		player.lhealth = player.health;
    		player.health = 1000;
    		Destroy(gameObject);
   			Instantiate(shield_bar, new Vector3( 5.0f, 2.5f, 1.0f ), Quaternion.identity);
    	}
    }
}
