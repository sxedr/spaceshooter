﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pUptime3 : MonoBehaviour
{
    public GameObject shield_bar;
	float i = 200;
	float scale = 1;
    void FixedUpdate()
    {
        transform.localScale = new Vector3(scale, 1f);
	    i--;
	    scale = i/200;
	    if(i == 0){
	    	Destroy(shield_bar);
	    }    
    }
}
