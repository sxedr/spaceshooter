﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class heal : MonoBehaviour
{
    private Player player;
	int timer;
	void Start(){
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
	}
	void Update(){
		timer++;
		if(timer == 1000){
			Destroy(gameObject);
			Debug.Log("DesHeal");
		}
	}
	void OnTriggerEnter2D(Collider2D other){
    	if(other.CompareTag("Player")){
    		player.health += 2;
    		if(player.health + 2 > 10){
    			player.health = 10;
    		}
    		Destroy(gameObject);
    	}
    }
}
