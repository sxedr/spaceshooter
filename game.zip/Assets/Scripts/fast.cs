﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fast : MonoBehaviour
{
	public GameObject fast_bar;
    private Player player;
	int timer;
	void Start(){
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
	}
	void Update(){
		timer++;
		if(timer == 1000){
			Destroy(gameObject);
			Debug.Log("DesFast");
		}

	}
	void OnTriggerEnter2D(Collider2D other){
    	if(other.CompareTag("Player")){
    		player.speed = 8.5f;
    		Destroy(gameObject);
   			Instantiate(fast_bar, new Vector3( 5.0f, 2.5f, 1.0f ), Quaternion.identity);
    	}
    }
}
