﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
	public GameObject shot;
	public GameObject shotWinchester;
	private Transform playerPos;
	private Player player;
    public int weapon = 1;
    public float fireRate;
    float timeUntilFire = 0;

	void Start(){
		playerPos = GetComponent<Transform>();
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
	}

	void Update(){
		if(Input.GetKeyDown("1")){
    		weapon = 1;
    		Debug.Log(weapon);
    	}
    	if(Input.GetKeyDown("2")){
    		weapon = 2;
    		Debug.Log(weapon);
    	}
    	if(Input.GetKeyDown("3")){
    		weapon = 3;
    		Debug.Log(weapon);
    	}
		if(Input.GetMouseButtonDown(0) && weapon == 1 && Time.time > timeUntilFire){
			GetComponent <AudioSource>().Play();
			fireRate = 3.0f;
			timeUntilFire = Time.time + 1/fireRate;
			Instantiate(shot, playerPos.position, playerPos.rotation);
		}
		if(Input.GetMouseButtonDown(0) && weapon == 2 && Time.time > timeUntilFire){
			fireRate = 1.7f;
			timeUntilFire = Time.time +1/fireRate;
			Instantiate(shotWinchester, playerPos.position, playerPos.rotation);
			/*Instantiate(shotWinchester, new Vector3( player.transform.position.x, player.transform.position.y + 0.35f, player.transform.position.z ), playerPos.rotation);
			Instantiate(shotWinchester, playerPos.position, playerPos.rotation);
			Instantiate(shotWinchester, new Vector3( player.transform.position.x, player.transform.position.y - 0.35f, player.transform.position.z ), playerPos.rotation);*/
		}
	}
}
