﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damage : MonoBehaviour
{
	public GameObject dmg_bar;
	private Player player;
	int timer;
	void Start(){
		player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
	}
	void FixedUpdate(){
		timer++;
		if(timer == 1000){
			Destroy(gameObject);
			Debug.Log("DesDmg");
		}

	}
	void OnTriggerEnter2D(Collider2D other){
    	if(other.CompareTag("Player")){
    		player.attack = 2;
    		Destroy(gameObject);
   			Instantiate(dmg_bar, new Vector3( 5.0f, 2.5f, 1.0f ), Quaternion.identity);
    	}
    }
}
