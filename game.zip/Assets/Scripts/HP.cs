﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HP : MonoBehaviour
{
	private Player player;
	float hp;
    // Start is called before the first frame update
    void Start()
    {
    	player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>(); 
    }

    // Update is called once per frame
    void Update()
    {
    	if(player.health == 10){
    		hp = 1.0f;
    	}
    	if(player.health == 9){
    		hp = 0.9f;
    	}
    	if(player.health == 8){
    		hp = 0.8f;
    	}
    	if(player.health == 7){
    		hp = 0.7f;
    	}
    	if(player.health == 6){
    		hp = 0.6f;
    	}
    	if(player.health == 5){
    		hp = 0.5f;
    	}
    	if(player.health == 4){
    		hp = 0.4f;
    	}
    	if(player.health == 3){
    		hp = 0.3f;
    	}
    	if(player.health == 2){
    		hp = 0.2f;
    	}
    	if(player.health == 1){
    		hp = 0.1f;
    	}
    	if(player.health <= 0){
    		hp = 0.0f;
    	}
        transform.localScale = new Vector3(hp, 1f);
    }
}
