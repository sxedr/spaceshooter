﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Winchester : MonoBehaviour
{
	public float speed;
	void Start(){
	}

	void Update(){
		this.transform.Translate(Vector2.up * speed * Time.deltaTime);
	}

	void OnTriggerEnter2D(Collider2D other){
		if(other.CompareTag("enemy") || other.CompareTag("fastEnemy") || other.CompareTag("bigEnemy") || other.CompareTag("smallEnemy")){
			Destroy(gameObject);
		}
	}
}
